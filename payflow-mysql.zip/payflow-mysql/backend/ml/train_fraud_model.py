"""
PayFlow AI Fraud Detection - Model Training
=============================================
Trains two complementary models used by the Fraud Detection (ML Service):

1. RandomForestClassifier  -> supervised risk-scoring model (probability of fraud)
   Features: amount, hour_of_day, is_new_beneficiary, txn_count_last_24h,
             avg_amount_last_30d, amount_to_avg_ratio, is_high_risk_type

2. IsolationForest          -> unsupervised anomaly detector, used as a secondary
   signal so unseen fraud *patterns* (not just labelled fraud) can still be
   flagged for manual review.

In production this would train on real historical transaction data pulled
from the MySQL database. Here we generate realistic synthetic data so the
service is runnable end-to-end out of the box. Re-run this script whenever
you want to retrain on fresh data (e.g. exported from `transactions` table).

Usage:
    python train_fraud_model.py
Outputs:
    fraud_rf_model.pkl        (classifier)
    fraud_isolation_model.pkl (anomaly detector)
    fraud_scaler.pkl          (feature scaler)
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
import os

RNG = np.random.default_rng(42)
N = 20000

def generate_synthetic_data(n=N):
    amount = np.round(RNG.lognormal(mean=6.5, sigma=1.3, size=n), 2)  # skewed like real txns
    hour_of_day = RNG.integers(0, 24, size=n)
    is_new_beneficiary = RNG.binomial(1, 0.25, size=n)
    txn_count_last_24h = RNG.poisson(2.5, size=n)
    avg_amount_last_30d = np.round(RNG.lognormal(mean=6.2, sigma=0.9, size=n), 2)
    amount_to_avg_ratio = amount / np.maximum(avg_amount_last_30d, 1)
    is_high_risk_type = RNG.binomial(1, 0.15, size=n)  # e.g. wallet/qr to unknown merchant

    # latent fraud-probability driven by realistic risk factors
    risk_logit = (
        -4.2
        + 0.9 * (amount_to_avg_ratio > 5)
        + 0.7 * is_new_beneficiary
        + 0.6 * (txn_count_last_24h > 6)
        + 0.5 * ((hour_of_day < 5) | (hour_of_day > 23))
        + 0.8 * is_high_risk_type
        + 0.00002 * amount
    )
    fraud_prob = 1 / (1 + np.exp(-risk_logit))
    is_fraud = RNG.binomial(1, fraud_prob)

    df = pd.DataFrame({
        "amount": amount,
        "hour_of_day": hour_of_day,
        "is_new_beneficiary": is_new_beneficiary,
        "txn_count_last_24h": txn_count_last_24h,
        "avg_amount_last_30d": avg_amount_last_30d,
        "amount_to_avg_ratio": amount_to_avg_ratio,
        "is_high_risk_type": is_high_risk_type,
        "is_fraud": is_fraud,
    })
    return df


def train():
    df = generate_synthetic_data()
    feature_cols = [
        "amount", "hour_of_day", "is_new_beneficiary", "txn_count_last_24h",
        "avg_amount_last_30d", "amount_to_avg_ratio", "is_high_risk_type",
    ]
    X = df[feature_cols].values
    y = df["is_fraud"].values

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=200, max_depth=8, class_weight="balanced", random_state=42
    )
    clf.fit(X_train, y_train)

    print("=== RandomForest Fraud Classifier ===")
    print(classification_report(y_test, clf.predict(X_test)))

    # Unsupervised anomaly detector trained only on legitimate transactions
    iso = IsolationForest(contamination=0.05, random_state=42)
    iso.fit(X_scaled[y == 0])

    out_dir = os.path.dirname(os.path.abspath(__file__))
    joblib.dump(clf, os.path.join(out_dir, "fraud_rf_model.pkl"))
    joblib.dump(iso, os.path.join(out_dir, "fraud_isolation_model.pkl"))
    joblib.dump(scaler, os.path.join(out_dir, "fraud_scaler.pkl"))
    joblib.dump(feature_cols, os.path.join(out_dir, "fraud_feature_cols.pkl"))
    print(f"\nModels saved to {out_dir}")


if __name__ == "__main__":
    train()
