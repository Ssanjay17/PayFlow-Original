"""
AI Fraud Detection & Risk Scoring
==================================
Mirrors the "Fraud Detection (ML Service)" box in the backend microservices
layer and step 4 of the Request Flow: "Fraud Check (ML Service) - Transaction
risk score evaluated by Fraud Detection Service".

Combines:
  - RandomForestClassifier -> supervised fraud probability
  - IsolationForest         -> unsupervised anomaly signal
into a single blended risk_score in [0, 1].

Decision bands (configurable via .env):
  risk_score >= FRAUD_BLOCK_THRESHOLD   -> block
  risk_score >= FRAUD_REVIEW_THRESHOLD  -> review (held for manual/operator check)
  else                                  -> allow
"""
import os
from datetime import datetime, timedelta
import numpy as np
import joblib
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.config import settings
from app.models.transaction import Transaction

_ML_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "ml")


class FraudDetectionService:
    def __init__(self):
        self.clf = joblib.load(os.path.join(_ML_DIR, "fraud_rf_model.pkl"))
        self.iso = joblib.load(os.path.join(_ML_DIR, "fraud_isolation_model.pkl"))
        self.scaler = joblib.load(os.path.join(_ML_DIR, "fraud_scaler.pkl"))
        self.feature_cols = joblib.load(os.path.join(_ML_DIR, "fraud_feature_cols.pkl"))

    def _build_features(self, db: Session, sender_id: str, amount: float,
                         txn_type: str, is_new_beneficiary: bool) -> np.ndarray:
        now = datetime.utcnow()
        hour_of_day = now.hour

        txn_count_last_24h = (
            db.query(func.count(Transaction.id))
            .filter(Transaction.sender_id == sender_id, Transaction.created_at >= now - timedelta(hours=24))
            .scalar() or 0
        )

        avg_amount_last_30d = (
            db.query(func.avg(Transaction.amount))
            .filter(Transaction.sender_id == sender_id, Transaction.created_at >= now - timedelta(days=30))
            .scalar()
        )
        avg_amount_last_30d = float(avg_amount_last_30d) if avg_amount_last_30d else max(amount, 1.0)

        amount_to_avg_ratio = amount / max(avg_amount_last_30d, 1.0)
        is_high_risk_type = 1 if txn_type in ("wallet", "qr_payment") else 0

        row = {
            "amount": amount,
            "hour_of_day": hour_of_day,
            "is_new_beneficiary": int(is_new_beneficiary),
            "txn_count_last_24h": txn_count_last_24h,
            "avg_amount_last_30d": avg_amount_last_30d,
            "amount_to_avg_ratio": amount_to_avg_ratio,
            "is_high_risk_type": is_high_risk_type,
        }
        return np.array([[row[c] for c in self.feature_cols]])

    def score_transaction(self, db: Session, sender_id: str, amount: float,
                           txn_type: str, is_new_beneficiary: bool = False) -> dict:
        X = self._build_features(db, sender_id, amount, txn_type, is_new_beneficiary)
        X_scaled = self.scaler.transform(X)

        fraud_prob = float(self.clf.predict_proba(X_scaled)[0][1])

        # IsolationForest: decision_function > 0 normal, < 0 anomalous. Normalize to [0,1] "anomaly score".
        anomaly_raw = float(self.iso.decision_function(X_scaled)[0])
        anomaly_score = float(np.clip(0.5 - anomaly_raw, 0, 1))

        # Blend: weight supervised model higher, anomaly detector as a secondary boost
        risk_score = round(0.7 * fraud_prob + 0.3 * anomaly_score, 4)

        if risk_score >= settings.FRAUD_BLOCK_THRESHOLD:
            status = "block"
            reason = "High-confidence fraud pattern detected by AI risk model"
        elif risk_score >= settings.FRAUD_REVIEW_THRESHOLD:
            status = "review"
            reason = "Elevated risk score - flagged for manual/operator review"
        else:
            status = "allow"
            reason = "Transaction within normal risk profile"

        return {"risk_score": risk_score, "status": status, "reason": reason}


fraud_service = FraudDetectionService()
