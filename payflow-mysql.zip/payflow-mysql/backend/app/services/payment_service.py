"""
Payment Service — implements Section 4 "REQUEST FLOW (PAYMENT FLOW)" step by step:

  1. User Initiates Payment      - user enters amount and selects receiver (UPI/Account/Mobile)
  2. Request Goes to API Gateway - request validated, authenticated and routed to Payment Service
  3. Check Balance & Validate    - Payment Service checks balance, limits and validates request
  4. Fraud Check (ML Service)    - transaction risk score evaluated by Fraud Detection Service
  5. Process Payment             - amount debited from sender and credited to receiver
  6. Update Databases            - transaction stored in SQL DB, cache updated in Redis
  7. Send Notification           - SMS / Push / Email sent to user
  8. Return Response             - success response returned to client with transaction ID

Each step is a clearly separated method so the mapping to the diagram (and to
future standalone microservice containers) stays obvious.
"""
import uuid
from decimal import Decimal
from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.config import settings
from app.core.security import verify_secret
from app.models.user import User
from app.models.account import Account
from app.models.transaction import Transaction, TxnType, TxnStatus
from app.models.fraud import FraudCheck
from app.services.fraud_service import fraud_service
from app.services.cache_service import cache_set, cache_delete
from app.services.notification_service import notify_user


def _generate_txn_ref() -> str:
    return f"PYFL{uuid.uuid4().hex[:12].upper()}"


def _resolve_receiver(db: Session, identifier: str) -> User | None:
    """Resolve receiver by UPI ID, account number, or mobile number."""
    account = (
        db.query(Account)
        .filter((Account.upi_id == identifier) | (Account.account_no == identifier))
        .first()
    )
    if account:
        return db.query(User).filter(User.id == account.user_id).first()
    return db.query(User).filter(User.mobile == identifier).first()


def process_payment(db: Session, sender: User, receiver_identifier: str,
                     amount: float, txn_type: str, pin: str, pin_hash: str,
                     note: str | None = None) -> dict:

    # ---- Step 2: API Gateway already authenticated the user (JWT dependency).
    #      Here we validate the request payload itself.
    if amount <= 0:
        raise HTTPException(400, "Amount must be greater than zero")
    if txn_type not in [t.value for t in TxnType]:
        raise HTTPException(400, "Invalid transaction type")
    if not verify_secret(pin, pin_hash):
        raise HTTPException(401, "Invalid transaction PIN")

    # ---- Step 1: identify receiver from UPI / Account / Mobile input
    receiver = _resolve_receiver(db, receiver_identifier) if txn_type in (
        "upi", "bank_transfer", "qr_payment", "wallet"
    ) else None

    if txn_type in ("upi", "bank_transfer", "qr_payment", "wallet") and receiver is None:
        raise HTTPException(404, "Receiver not found")
    if receiver and receiver.id == sender.id:
        raise HTTPException(400, "Cannot pay yourself")

    # ---- Step 3: Check balance & validate limits
    sender_account = db.query(Account).filter(Account.user_id == sender.id).first()
    if not sender_account:
        raise HTTPException(404, "Sender account not found")
    if Decimal(str(amount)) > sender_account.balance:
        raise HTTPException(400, "Insufficient balance")
    if amount > settings.DAILY_TRANSFER_LIMIT:
        raise HTTPException(400, f"Amount exceeds daily transfer limit of {settings.DAILY_TRANSFER_LIMIT}")

    is_new_beneficiary = False
    if receiver:
        from app.models.beneficiary import Beneficiary
        existing = db.query(Beneficiary).filter(
            Beneficiary.user_id == sender.id, Beneficiary.account_no == receiver_identifier
        ).first()
        is_new_beneficiary = existing is None

    # Create the transaction record up front in "initiated" state
    txn = Transaction(
        sender_id=sender.id,
        receiver_id=receiver.id if receiver else None,
        amount=amount,
        type=TxnType(txn_type),
        status=TxnStatus.initiated,
        txn_ref_no=_generate_txn_ref(),
    )
    db.add(txn)
    db.commit()
    db.refresh(txn)

    # ---- Step 4: AI Fraud Check (ML Service)
    fraud_result = fraud_service.score_transaction(
        db, sender_id=sender.id, amount=amount, txn_type=txn_type,
        is_new_beneficiary=is_new_beneficiary,
    )
    fraud_check = FraudCheck(
        transaction_id=txn.id,
        risk_score=fraud_result["risk_score"],
        status=fraud_result["status"],
        reason=fraud_result["reason"],
    )
    db.add(fraud_check)

    if fraud_result["status"] == "block":
        txn.status = TxnStatus.blocked_fraud
        db.commit()
        notify_user(db, sender.id, f"Transaction {txn.txn_ref_no} was blocked for suspicious activity.", "push")
        return {
            "txn_id": txn.id, "txn_ref_no": txn.txn_ref_no, "status": txn.status.value,
            "risk_score": fraud_result["risk_score"],
            "message": "Transaction blocked by AI Fraud Detection. Contact support if this was you.",
        }

    if fraud_result["status"] == "review":
        txn.status = TxnStatus.under_review
        db.commit()
        notify_user(db, sender.id, f"Transaction {txn.txn_ref_no} is under review for verification.", "push")
        return {
            "txn_id": txn.id, "txn_ref_no": txn.txn_ref_no, "status": txn.status.value,
            "risk_score": fraud_result["risk_score"],
            "message": "Transaction flagged for manual review. It will complete once cleared.",
        }

    # ---- Step 5: Process Payment (debit sender, credit receiver)
    sender_account.balance = sender_account.balance - Decimal(str(amount))
    receiver_account = None
    if receiver:
        receiver_account = db.query(Account).filter(Account.user_id == receiver.id).first()
        if receiver_account:
            receiver_account.balance = receiver_account.balance + Decimal(str(amount))

    txn.status = TxnStatus.success
    db.commit()
    db.refresh(txn)

    # ---- Step 6: Update Databases (SQL committed above) + Redis cache
    cache_set(f"balance:{sender.id}", float(sender_account.balance), ttl_seconds=600)
    cache_delete(f"balance:{sender.id}:stale")
    if receiver_account:
        cache_set(f"balance:{receiver.id}", float(receiver_account.balance), ttl_seconds=600)

    # ---- Step 7: Send Notification (SMS/Push/Email)
    notify_user(db, sender.id, f"₹{amount} debited via {txn_type.upper()}. Ref: {txn.txn_ref_no}", "sms")
    if receiver:
        notify_user(db, receiver.id, f"₹{amount} credited to your account. Ref: {txn.txn_ref_no}", "push")

    # ---- Step 8: Return Response
    return {
        "txn_id": txn.id,
        "txn_ref_no": txn.txn_ref_no,
        "status": txn.status.value,
        "risk_score": fraud_result["risk_score"],
        "message": "Payment successful",
    }
