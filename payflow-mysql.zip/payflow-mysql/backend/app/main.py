"""
PayFlow - Digital Banking & Payments Platform
Backend entry point (acts as the API Gateway from the architecture diagram:
Authentication, Rate Limiting, Request Routing to the microservice routers
below).

Run (normal / non-container mode):
    cd backend
    cp .env.example .env      # then edit MYSQL_URL credentials
    pip install -r requirements.txt --break-system-packages
    python ml/train_fraud_model.py     # generates the fraud detection model
    uvicorn app.main:app --reload --port 8000

Docs: http://localhost:8000/docs
Web app: http://localhost:8000/app
"""
import os
import time
from collections import defaultdict
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.database import Base, engine
from app import models  # noqa: ensures all models are registered with Base
from app.config import settings

from app.routers import auth, users, accounts, beneficiaries, payments, transactions, notifications, kyc, admin

app = FastAPI(
    title="PayFlow API",
    description="Secure • Fast • Intelligent • Scalable — Digital Banking & Payments Platform",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---- Simple in-process rate limiting (API Gateway responsibility) ----
_request_log: dict[str, list[float]] = defaultdict(list)
RATE_LIMIT = 120          # requests
RATE_WINDOW_SECONDS = 60  # per minute


@app.middleware("http")
async def rate_limiter(request: Request, call_next):
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    window_start = now - RATE_WINDOW_SECONDS
    _request_log[client_ip] = [t for t in _request_log[client_ip] if t > window_start]

    if len(_request_log[client_ip]) >= RATE_LIMIT:
        return JSONResponse(status_code=429, content={"detail": "Rate limit exceeded. Try again shortly."})

    _request_log[client_ip].append(now)
    return await call_next(request)


@app.on_event("startup")
def on_startup():
    # Creates tables if they don't exist (MySQL).
    Base.metadata.create_all(bind=engine)


@app.get("/", tags=["Health"])
def root():
    return {
        "service": "PayFlow API Gateway",
        "status": "healthy",
        "db_engine": "mysql",
        "features": [
            "UPI Payments", "Bill Payments", "Bank Transfer", "Recharge", "Wallet", "QR Payments",
            "AI Fraud Detection", "Real-time Notifications", "Operator/Admin Panel",
        ],
    }


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}


# ---- Route requests to backend microservice routers (API Gateway pattern) ----
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(accounts.router)
app.include_router(beneficiaries.router)
app.include_router(payments.router)
app.include_router(transactions.router)
app.include_router(notifications.router)
app.include_router(kyc.router)
app.include_router(admin.router)

# ---- Serve the frontend (plain HTML/JS/CSS) at /app ----
# Mounted last so it never shadows the /api/* routes above.
_FRONTEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "frontend"))
if os.path.isdir(_FRONTEND_DIR):
    app.mount("/app", StaticFiles(directory=_FRONTEND_DIR, html=True), name="frontend")
