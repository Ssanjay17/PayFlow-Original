from datetime import datetime
from pydantic import BaseModel


class UserOut(BaseModel):
    id: str
    name: str
    email: str
    mobile: str
    status: str
    role: str
    created_at: datetime

    class Config:
        from_attributes = True


class AccountOut(BaseModel):
    id: str
    account_no: str
    ifsc: str
    bank_name: str
    balance: float
    upi_id: str | None

    class Config:
        from_attributes = True


class BeneficiaryIn(BaseModel):
    name: str
    account_no: str | None = None
    ifsc_or_upi_id: str | None = None
    type: str = "bank"


class BeneficiaryOut(BeneficiaryIn):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True
