from datetime import datetime
from pydantic import BaseModel, Field


class PaymentRequest(BaseModel):
    receiver_identifier: str = Field(..., description="UPI ID, account number, or mobile of receiver")
    amount: float = Field(..., gt=0)
    type: str = Field(..., description="upi | bank_transfer | bill_payment | recharge | wallet | qr_payment")
    pin: str = Field(..., description="4-6 digit transaction PIN for verification")
    note: str | None = None


class PaymentResponse(BaseModel):
    txn_id: str
    txn_ref_no: str
    status: str
    risk_score: float
    message: str


class TransactionOut(BaseModel):
    id: str
    sender_id: str
    receiver_id: str | None
    amount: float
    type: str
    status: str
    txn_ref_no: str
    created_at: datetime

    class Config:
        from_attributes = True


class BalanceRequestIn(BaseModel):
    amount: float = Field(..., gt=0)
    note: str | None = None


class BalanceRequestOut(BaseModel):
    id: str
    user_id: str
    amount: float
    note: str | None
    status: str
    remarks: str | None
    created_at: datetime
    decided_at: datetime | None

    class Config:
        from_attributes = True