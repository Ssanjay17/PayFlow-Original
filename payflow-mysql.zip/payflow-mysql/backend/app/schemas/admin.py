from pydantic import BaseModel


class DashboardStats(BaseModel):
    total_users: int
    total_transactions: int
    total_amount: float
    active_frauds: int
    pending_kyc: int


class PaymentMethodShare(BaseModel):
    method: str
    percent: float


class TrendPoint(BaseModel):
    label: str
    amount: float


class AdminCreateIn(BaseModel):
    name: str
    email: str
    password: str
    role: str = "admin"  # "admin" or "operator"
    mobile: str | None = None
    pin: str | None = None


class AdminCreateOut(BaseModel):
    id: str
    email: str
    role: str
    mobile: str
    generated_pin: str | None = None  # only returned when we auto-generated one


class BalanceAdjustIn(BaseModel):
    amount: float  # positive = credit, negative = debit
    remarks: str | None = None