from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    name: str
    email: EmailStr
    mobile: str = Field(min_length=10, max_length=15)
    password: str = Field(min_length=6)
    pin: str = Field(min_length=4, max_length=6, description="4-6 digit transaction PIN")


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class SetupAdminRequest(BaseModel):
    name: str
    email: EmailStr
    mobile: str = Field(min_length=10, max_length=15)
    password: str = Field(min_length=6)
    pin: str = Field(min_length=4, max_length=6, description="4-6 digit transaction PIN")


class SetupStatusResponse(BaseModel):
    admin_exists: bool


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    name: str
    role: str
