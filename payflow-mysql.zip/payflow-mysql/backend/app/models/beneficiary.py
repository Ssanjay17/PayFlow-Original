import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey
from app.database import Base


class Beneficiary(Base):
    __tablename__ = "beneficiaries"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    name = Column(String(120), nullable=False)
    account_no = Column(String(30), nullable=True)
    ifsc_or_upi_id = Column(String(80), nullable=True)
    type = Column(String(20), default="bank")  # bank | upi
    created_at = Column(DateTime, default=datetime.utcnow)
