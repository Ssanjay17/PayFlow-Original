import uuid
import enum
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Numeric, Enum, ForeignKey
from app.database import Base


class BalanceRequestStatus(str, enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"


class BalanceRequest(Base):
    """A customer's self-service 'Add Money' request. Stays pending until an
    operator/admin approves or rejects it in the Admin Panel — approval is
    what actually credits the linked Account.balance (see routers/admin.py)."""
    __tablename__ = "balance_requests"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    amount = Column(Numeric(14, 2), nullable=False)
    note = Column(String(255), nullable=True)
    status = Column(Enum(BalanceRequestStatus), default=BalanceRequestStatus.pending, index=True)
    decided_by = Column(String(36), ForeignKey("users.id"), nullable=True)
    remarks = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    decided_at = Column(DateTime, nullable=True)