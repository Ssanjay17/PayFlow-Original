import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Enum
import enum
from app.database import Base


class UserStatus(str, enum.Enum):
    active = "active"
    suspended = "suspended"
    pending_kyc = "pending_kyc"


class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(120), nullable=False)
    email = Column(String(150), unique=True, nullable=False, index=True)
    mobile = Column(String(15), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    status = Column(Enum(UserStatus), default=UserStatus.pending_kyc)
    role = Column(String(20), default="customer")  # customer | operator | admin
    created_at = Column(DateTime, default=datetime.utcnow)
