import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Float, ForeignKey
from app.database import Base


class FraudCheck(Base):
    __tablename__ = "fraud_checks"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    transaction_id = Column(String(36), ForeignKey("transactions.id"), nullable=False, index=True)
    risk_score = Column(Float, nullable=False)
    status = Column(String(20), nullable=False)  # allow | review | block
    reason = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
