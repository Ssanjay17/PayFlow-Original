import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Numeric, ForeignKey
from app.database import Base


class Account(Base):
    __tablename__ = "accounts"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    account_no = Column(String(30), unique=True, nullable=False)
    ifsc = Column(String(15), nullable=False)
    bank_name = Column(String(100), nullable=False)
    balance = Column(Numeric(14, 2), default=0)
    upi_id = Column(String(80), unique=True, nullable=True)
    pin_hash = Column(String(255), nullable=False)  # hashed transaction PIN (Secure Authentication)
    created_at = Column(DateTime, default=datetime.utcnow)
