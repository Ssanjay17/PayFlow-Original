from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.account import Account
from app.schemas.user import AccountOut
from app.services.cache_service import cache_get

router = APIRouter(prefix="/api/accounts", tags=["Account Service"])


@router.get("/me", response_model=AccountOut)
def get_my_account(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    account = db.query(Account).filter(Account.user_id == current_user.id).first()
    if not account:
        raise HTTPException(404, "Account not found")
    return account


@router.get("/me/balance")
def check_balance(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Step 1 of user journey: 'Check Balance / Recent Activity'. Tries Redis cache first."""
    cached = cache_get(f"balance:{current_user.id}")
    if cached is not None:
        return {"balance": cached, "source": "cache"}

    account = db.query(Account).filter(Account.user_id == current_user.id).first()
    if not account:
        raise HTTPException(404, "Account not found")
    return {"balance": float(account.balance), "source": "database"}
