from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.kyc import KycDetail

router = APIRouter(prefix="/api/kyc", tags=["KYC"])


class KycSubmitRequest(BaseModel):
    kyc_type: str
    doc_url: str


@router.post("/submit", status_code=201)
def submit_kyc(payload: KycSubmitRequest, db: Session = Depends(get_db),
                current_user: User = Depends(get_current_user)):
    kyc = KycDetail(user_id=current_user.id, kyc_type=payload.kyc_type, doc_url=payload.doc_url, status="pending")
    db.add(kyc)
    db.commit()
    db.refresh(kyc)
    return {"id": kyc.id, "status": kyc.status, "message": "KYC submitted for verification"}


@router.get("/status")
def kyc_status(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    records = db.query(KycDetail).filter(KycDetail.user_id == current_user.id).all()
    return [{"kyc_type": r.kyc_type, "status": r.status, "verified_at": r.verified_at} for r in records]
