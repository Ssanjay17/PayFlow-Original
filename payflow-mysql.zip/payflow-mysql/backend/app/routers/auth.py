import random
import string
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User, UserStatus
from app.models.account import Account
from app.schemas.auth import (
    RegisterRequest, LoginRequest, TokenResponse, SetupAdminRequest, SetupStatusResponse,
)
from app.core.security import hash_secret, verify_secret, create_access_token

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


def _generate_account_no() -> str:
    return "PF" + "".join(random.choices(string.digits, k=12))


def _generate_upi_id(mobile: str) -> str:
    return f"{mobile}@payflow"


@router.post("/register", response_model=TokenResponse, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(400, "Email already registered")
    if db.query(User).filter(User.mobile == payload.mobile).first():
        raise HTTPException(400, "Mobile already registered")

    user = User(
        name=payload.name,
        email=payload.email,
        mobile=payload.mobile,
        password_hash=hash_secret(payload.password),
        status=UserStatus.pending_kyc,
        role="customer",
    )
    db.add(user)
    db.flush()  # assigns user.id without committing yet

    # Auto-provision a linked account (Bank Account Management feature).
    # Committed together with the user so a User row can never exist without
    # its Account row (this was the cause of "Account not found" in the UI
    # when the account insert failed after the user insert had already committed).
    account = Account(
        user_id=user.id,
        account_no=_generate_account_no(),
        ifsc="PYFL0001234",
        bank_name="PayFlow Bank",
        balance=0,
        upi_id=_generate_upi_id(user.mobile),
        pin_hash=hash_secret(payload.pin),
    )
    db.add(account)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(500, "Registration failed, please try again")
    db.refresh(user)

    token = create_access_token({"sub": user.id, "role": user.role})
    return TokenResponse(access_token=token, user_id=user.id, name=user.name, role=user.role)


# ---------------------------------------------------------------------------
# One-time admin setup (UI-driven, but locked shut the moment one exists).
#
# There is NO role field on /register and NO way to reach admin/operator
# through the normal Login/Register panels. This pair of endpoints is the
# only UI path that can ever create an admin, and it self-destructs:
#   - setup-status just tells the frontend whether to show the "first-time
#     setup" link at all.
#   - setup-admin re-checks for an existing admin/operator INSIDE the
#     request itself, so the one-time-ness is enforced by the database
#     state, not by the frontend hiding a button. Once any admin/operator
#     row exists, every subsequent call 403s. (This app has one operator
#     hitting this once during initial setup, so a plain check-then-insert
#     is fine; it is not hardened against two truly simultaneous first
#     requests racing each other — that would need a DB-level lock/unique
#     constraint, which isn't worth the complexity here.)
# ---------------------------------------------------------------------------
def _admin_exists(db: Session) -> bool:
    return db.query(User).filter(User.role.in_(["admin", "operator"])).first() is not None


@router.get("/setup-status", response_model=SetupStatusResponse)
def setup_status(db: Session = Depends(get_db)):
    return SetupStatusResponse(admin_exists=_admin_exists(db))


@router.post("/setup-admin", response_model=TokenResponse, status_code=201)
def setup_admin(payload: SetupAdminRequest, db: Session = Depends(get_db)):
    if _admin_exists(db):
        raise HTTPException(403, "Admin setup already completed. This can only be done once.")
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(400, "Email already registered")
    if db.query(User).filter(User.mobile == payload.mobile).first():
        raise HTTPException(400, "Mobile already registered")

    user = User(
        name=payload.name,
        email=payload.email,
        mobile=payload.mobile,
        password_hash=hash_secret(payload.password),
        status=UserStatus.active,
        role="admin",
    )
    db.add(user)
    db.flush()

    account = Account(
        user_id=user.id,
        account_no=_generate_account_no(),
        ifsc="PYFL0001234",
        bank_name="PayFlow Bank",
        balance=0,
        upi_id=_generate_upi_id(user.mobile),
        pin_hash=hash_secret(payload.pin),
    )
    db.add(account)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(500, "Admin setup failed, please try again")
    db.refresh(user)

    token = create_access_token({"sub": user.id, "role": user.role})
    return TokenResponse(access_token=token, user_id=user.id, name=user.name, role=user.role)


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_secret(payload.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    if user.status == UserStatus.suspended:
        raise HTTPException(403, "Account suspended. Contact support.")

    token = create_access_token({"sub": user.id, "role": user.role})
    return TokenResponse(access_token=token, user_id=user.id, name=user.name, role=user.role)
