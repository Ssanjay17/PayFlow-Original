"""
Operator / Admin Panel — mirrors Section 8 of the architecture:
  - User Management
  - KYC Verification
  - Transaction Monitoring
  - Dispute Management
  - Fraud Alerts & Analysis
  - Reports & Analytics
  - System Configuration
Plus the dashboard widgets: Total Users / Total Transactions / Total Amount,
Transaction Trend, Top Payment Methods, Recent Transactions.
"""
import random
import string
import uuid
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel

from app.database import get_db
from app.core.deps import require_operator, require_admin
from app.core.security import hash_secret
from app.models.user import User, UserStatus
from app.models.account import Account
from app.models.transaction import Transaction, TxnStatus, TxnType
from app.models.kyc import KycDetail
from app.models.fraud import FraudCheck
from app.models.balance_request import BalanceRequest, BalanceRequestStatus
from app.schemas.user import UserOut
from app.schemas.payment import TransactionOut
from app.schemas.admin import AdminCreateIn, AdminCreateOut, BalanceAdjustIn

router = APIRouter(prefix="/api/admin", tags=["Operator / Admin Panel"])


# ---------- Dashboard ----------
@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), _=Depends(require_operator)):
    total_users = db.query(func.count(User.id)).scalar() or 0
    total_txns = db.query(func.count(Transaction.id)).scalar() or 0
    total_amount = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(
        Transaction.status == TxnStatus.success
    ).scalar() or 0
    active_frauds = db.query(func.count(FraudCheck.id)).filter(FraudCheck.status != "allow").scalar() or 0
    pending_kyc = db.query(func.count(User.id)).filter(User.status == UserStatus.pending_kyc).scalar() or 0

    # Transaction trend: last 7 days total amount
    trend = []
    for i in range(6, -1, -1):
        day = (datetime.utcnow() - timedelta(days=i)).date()
        day_total = (
            db.query(func.coalesce(func.sum(Transaction.amount), 0))
            .filter(func.date(Transaction.created_at) == day, Transaction.status == TxnStatus.success)
            .scalar() or 0
        )
        trend.append({"label": day.strftime("%d %b"), "amount": float(day_total)})

    # Top payment methods share
    method_rows = (
        db.query(Transaction.type, func.count(Transaction.id))
        .filter(Transaction.status == TxnStatus.success)
        .group_by(Transaction.type)
        .all()
    )
    total_method_txns = sum(c for _, c in method_rows) or 1
    top_methods = [
        {"method": t.value, "percent": round(c / total_method_txns * 100, 1)}
        for t, c in method_rows
    ]

    recent = (
        db.query(Transaction).order_by(Transaction.created_at.desc()).limit(10).all()
    )

    return {
        "total_users": total_users,
        "total_transactions": total_txns,
        "total_amount": float(total_amount),
        "active_frauds": active_frauds,
        "pending_kyc": pending_kyc,
        "transaction_trend": trend,
        "top_payment_methods": top_methods,
        "recent_transactions": [
            {
                "id": t.id, "amount": float(t.amount), "type": t.type.value,
                "status": t.status.value, "txn_ref_no": t.txn_ref_no,
                "created_at": t.created_at,
            } for t in recent
        ],
    }


# ---------- User Management ----------
@router.get("/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), _=Depends(require_operator)):
    return db.query(User).order_by(User.created_at.desc()).limit(200).all()


class UserStatusUpdate(BaseModel):
    status: str  # active | suspended | pending_kyc


@router.patch("/users/{user_id}/status")
def update_user_status(user_id: str, payload: UserStatusUpdate, db: Session = Depends(get_db),
                        _=Depends(require_operator)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    if payload.status not in [s.value for s in UserStatus]:
        raise HTTPException(400, "Invalid status")
    user.status = UserStatus(payload.status)
    db.commit()
    return {"message": f"User status updated to {payload.status}"}


# ---------- Admin / Operator Account Management (admin-only) ----------
@router.get("/admins", response_model=list[UserOut])
def list_admins(db: Session = Depends(get_db), _=Depends(require_admin)):
    return (
        db.query(User)
        .filter(User.role.in_(["admin", "operator"]))
        .order_by(User.created_at.desc())
        .all()
    )


@router.post("/create-admin", response_model=AdminCreateOut)
def create_admin_account(payload: AdminCreateIn, db: Session = Depends(get_db),
                          _=Depends(require_admin)):
    """Only an existing full admin can create new admin/operator accounts.
    There is no public/self-serve way to get this role — this endpoint plus
    the CLI create_admin.py script are the only two ways."""
    if payload.role not in ("admin", "operator"):
        raise HTTPException(400, "role must be 'admin' or 'operator'")
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(400, "A user with this email already exists")

    mobile = payload.mobile or ("9" + "".join(random.choices(string.digits, k=9)))
    pin = payload.pin or "".join(random.choices(string.digits, k=6))

    user = User(
        name=payload.name,
        email=payload.email,
        mobile=mobile,
        password_hash=hash_secret(payload.password),
        status=UserStatus.active,
        role=payload.role,
    )
    db.add(user)
    db.flush()  # get user.id before creating the linked account

    account = Account(
        user_id=user.id,
        account_no="PF" + "".join(random.choices(string.digits, k=12)),
        ifsc="PYFL0001234",
        bank_name="PayFlow Bank",
        balance=0,
        upi_id=f"{mobile}@payflow",
        pin_hash=hash_secret(pin),
    )
    db.add(account)
    db.commit()

    return AdminCreateOut(
        id=user.id,
        email=user.email,
        role=user.role,
        mobile=mobile,
        generated_pin=None if payload.pin else pin,  # only surface it if we made it up
    )


# ---------- Manual Balance Adjustment ----------
@router.post("/users/{user_id}/balance")
def adjust_balance(user_id: str, payload: BalanceAdjustIn, db: Session = Depends(get_db),
                    _=Depends(require_operator)):
    """Credit (positive amount) or debit (negative amount) a user's account
    balance directly, e.g. for manual top-ups, refunds, or corrections.
    Also writes a Transaction row so it shows up in the user's history and
    in Transaction Monitoring for audit purposes."""
    if payload.amount == 0:
        raise HTTPException(400, "Amount must be non-zero")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")

    account = db.query(Account).filter(Account.user_id == user_id).first()
    if not account:
        raise HTTPException(404, "This user has no bank account on file")

    new_balance = float(account.balance) + payload.amount
    if new_balance < 0:
        raise HTTPException(400, "Adjustment would take the balance negative")

    account.balance = new_balance

    txn = Transaction(
        sender_id=user_id,
        receiver_id=None,
        amount=abs(payload.amount),
        type=TxnType.wallet,
        status=TxnStatus.success,
        txn_ref_no=("ADJCR-" if payload.amount > 0 else "ADJDR-") + str(uuid.uuid4())[:10].upper(),
    )
    db.add(txn)
    db.commit()

    return {
        "message": f"Balance {'credited' if payload.amount > 0 else 'debited'} successfully",
        "new_balance": float(account.balance),
    }


# ---------- Add Money — Balance Requests (self-service, admin-approved) ----------
class BalanceRequestDecision(BaseModel):
    approve: bool
    remarks: str | None = None


@router.get("/balance-requests/pending")
def list_pending_balance_requests(db: Session = Depends(get_db), _=Depends(require_operator)):
    rows = (
        db.query(BalanceRequest, User)
        .join(User, User.id == BalanceRequest.user_id)
        .filter(BalanceRequest.status == BalanceRequestStatus.pending)
        .order_by(BalanceRequest.created_at)
        .all()
    )
    return [
        {
            "id": r.id, "user_id": r.user_id, "user_name": u.name, "user_email": u.email,
            "amount": float(r.amount), "note": r.note, "created_at": r.created_at,
        }
        for r, u in rows
    ]


@router.patch("/balance-requests/{request_id}/decision")
def decide_balance_request(request_id: str, payload: BalanceRequestDecision, db: Session = Depends(get_db),
                            operator: User = Depends(require_operator)):
    """Approving credits the customer's Account.balance and writes a Transaction
    audit row (ref prefixed ADDMNY-). Rejecting just closes the request out —
    nothing is touched."""
    req = db.query(BalanceRequest).filter(BalanceRequest.id == request_id).first()
    if not req:
        raise HTTPException(404, "Balance request not found")
    if req.status != BalanceRequestStatus.pending:
        raise HTTPException(400, f"Request was already {req.status.value}")

    req.status = BalanceRequestStatus.approved if payload.approve else BalanceRequestStatus.rejected
    req.remarks = payload.remarks
    req.decided_by = operator.id
    req.decided_at = datetime.utcnow()

    if payload.approve:
        account = db.query(Account).filter(Account.user_id == req.user_id).first()
        if not account:
            raise HTTPException(404, "This user has no bank account on file")

        account.balance = float(account.balance) + float(req.amount)

        txn = Transaction(
            sender_id=req.user_id,
            receiver_id=None,
            amount=req.amount,
            type=TxnType.wallet,
            status=TxnStatus.success,
            txn_ref_no="ADDMNY-" + str(uuid.uuid4())[:10].upper(),
        )
        db.add(txn)

    db.commit()
    return {"message": f"Request {req.status.value}"}


# ---------- KYC Verification ----------
@router.get("/kyc/pending")
def list_pending_kyc(db: Session = Depends(get_db), _=Depends(require_operator)):
    records = db.query(KycDetail).filter(KycDetail.status == "pending").all()
    return [
        {"id": r.id, "user_id": r.user_id, "kyc_type": r.kyc_type, "doc_url": r.doc_url,
         "created_at": r.created_at}
        for r in records
    ]


class KycDecision(BaseModel):
    approve: bool
    remarks: str | None = None


@router.patch("/kyc/{kyc_id}/decision")
def decide_kyc(kyc_id: str, payload: KycDecision, db: Session = Depends(get_db),
                _=Depends(require_operator)):
    record = db.query(KycDetail).filter(KycDetail.id == kyc_id).first()
    if not record:
        raise HTTPException(404, "KYC record not found")
    record.status = "verified" if payload.approve else "rejected"
    record.verified_at = datetime.utcnow()
    db.commit()

    if payload.approve:
        user = db.query(User).filter(User.id == record.user_id).first()
        if user and user.status == UserStatus.pending_kyc:
            user.status = UserStatus.active
            db.commit()

    return {"message": f"KYC {record.status}"}


# ---------- Transaction Monitoring ----------
@router.get("/transactions", response_model=list[TransactionOut])
def monitor_transactions(status: str | None = None, db: Session = Depends(get_db),
                          _=Depends(require_operator)):
    q = db.query(Transaction)
    if status:
        q = q.filter(Transaction.status == status)
    return q.order_by(Transaction.created_at.desc()).limit(200).all()


# ---------- Fraud Alerts & Analysis ----------
@router.get("/fraud-alerts")
def fraud_alerts(status: str | None = None, db: Session = Depends(get_db),
                  _=Depends(require_operator)):
    """Lists every AI-scored transaction (allow, review, block).
    Pass ?status=review or ?status=block to filter to flagged ones only."""
    q = db.query(FraudCheck)
    if status:
        q = q.filter(FraudCheck.status == status)
    alerts = q.order_by(FraudCheck.created_at.desc()).limit(100).all()
    return [
        {"id": a.id, "transaction_id": a.transaction_id, "risk_score": a.risk_score,
         "status": a.status, "reason": a.reason, "created_at": a.created_at}
        for a in alerts
    ]


# ---------- Dispute Management ----------
class DisputeAction(BaseModel):
    resolution: str  # refunded | rejected | escalated
    remarks: str | None = None


@router.post("/disputes/{txn_id}/resolve")
def resolve_dispute(txn_id: str, payload: DisputeAction, db: Session = Depends(get_db),
                     _=Depends(require_operator)):
    txn = db.query(Transaction).filter(Transaction.id == txn_id).first()
    if not txn:
        raise HTTPException(404, "Transaction not found")
    # In production this would reverse ledger entries on "refunded" etc.
    return {"txn_id": txn_id, "resolution": payload.resolution, "message": "Dispute resolution recorded"}


# ---------- Reports & Analytics ----------
@router.get("/reports/summary")
def reports_summary(db: Session = Depends(get_db), _=Depends(require_operator)):
    by_status = dict(
        db.query(Transaction.status, func.count(Transaction.id)).group_by(Transaction.status).all()
    )
    return {"transactions_by_status": {k.value: v for k, v in by_status.items()}}


# ---------- System Configuration ----------
class SystemConfig(BaseModel):
    fraud_block_threshold: float | None = None
    fraud_review_threshold: float | None = None
    daily_transfer_limit: float | None = None


@router.get("/config")
def get_config(_=Depends(require_operator)):
    from app.config import settings
    return {
        "fraud_block_threshold": settings.FRAUD_BLOCK_THRESHOLD,
        "fraud_review_threshold": settings.FRAUD_REVIEW_THRESHOLD,
        "daily_transfer_limit": settings.DAILY_TRANSFER_LIMIT,
    }