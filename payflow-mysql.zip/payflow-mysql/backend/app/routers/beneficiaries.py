from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.beneficiary import Beneficiary
from app.schemas.user import BeneficiaryIn, BeneficiaryOut

router = APIRouter(prefix="/api/beneficiaries", tags=["Beneficiaries"])


@router.post("", response_model=BeneficiaryOut, status_code=201)
def add_beneficiary(payload: BeneficiaryIn, db: Session = Depends(get_db),
                     current_user: User = Depends(get_current_user)):
    b = Beneficiary(user_id=current_user.id, **payload.model_dump())
    db.add(b)
    db.commit()
    db.refresh(b)
    return b


@router.get("", response_model=list[BeneficiaryOut])
def list_beneficiaries(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(Beneficiary).filter(Beneficiary.user_id == current_user.id).all()
