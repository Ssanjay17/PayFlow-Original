from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.database import get_db
from app.core.security import decode_access_token
from app.models.user import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login")


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise credentials_exception
    return user


def require_operator(user: User = Depends(get_current_user)) -> User:
    if user.role not in ("operator", "admin"):
        raise HTTPException(status_code=403, detail="Operator/Admin access required")
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    """Stricter than require_operator — only full admins may create other
    admin/operator accounts. Prevents an operator from self-escalating."""
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user