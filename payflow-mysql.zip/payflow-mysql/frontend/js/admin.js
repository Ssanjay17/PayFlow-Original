requireAuth();
const user = getUser();
if (!user || (user.role !== 'operator' && user.role !== 'admin')) {
  window.location.href = 'dashboard.html';
}
document.getElementById('sideName').textContent = user?.name || '—';
document.getElementById('avatarInit').textContent = initials(user?.name);
if (user?.role === 'admin') {
  document.getElementById('navAdmins').style.display = 'block';
}

function logout() { clearSession(); window.location.href = 'index.html'; }

const tabs = ['overview', 'users', 'kyc', 'balance', 'transactions', 'fraud', 'disputes', 'reports', 'config', 'admins'];
const tabTitles = {
  overview: 'Operator Dashboard', users: 'User Management', kyc: 'KYC Verification',
  balance: 'Balance Requests',
  transactions: 'Transaction Monitoring', fraud: 'Fraud Alerts & Analysis',
  disputes: 'Dispute Management', reports: 'Reports & Analytics', config: 'System Configuration',
  admins: 'Admin Accounts',
};
const loaders = {
  users: loadUsers, kyc: loadKyc, balance: loadBalanceRequests, transactions: loadTransactions, fraud: loadFraud,
  reports: loadReports, config: loadConfig, admins: loadAdmins,
};

function showTab(name, ev) {
  tabs.forEach(t => { document.getElementById('tab-' + t).style.display = t === name ? 'block' : 'none'; });
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const evt = ev || window.event;
  if (evt && evt.target) evt.target.classList.add('active');
  document.getElementById('pageTitle').textContent = tabTitles[name];
  if (loaders[name]) loaders[name]();
}

let trendChart, methodChart, reportChart;

async function loadOverview() {
  try {
    const d = await api('/api/admin/dashboard');
    document.getElementById('statUsers').textContent = d.total_users.toLocaleString('en-IN');
    document.getElementById('statTxns').textContent = d.total_transactions.toLocaleString('en-IN');
    document.getElementById('statAmount').textContent = money(d.total_amount);
    document.getElementById('statFrauds').textContent = d.active_frauds.toLocaleString('en-IN');

    const trendCtx = document.getElementById('trendChart');
    if (trendChart) trendChart.destroy();
    trendChart = new Chart(trendCtx, {
      type: 'line',
      data: {
        labels: d.transaction_trend.map(p => p.label),
        datasets: [{
          label: 'Amount', data: d.transaction_trend.map(p => p.amount),
          borderColor: '#2F6FED', backgroundColor: 'rgba(47,111,237,0.12)', fill: true, tension: 0.35,
        }],
      },
      options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } },
    });

    const methodCtx = document.getElementById('methodChart');
    if (methodChart) methodChart.destroy();
    const methods = d.top_payment_methods.length ? d.top_payment_methods : [{ method: 'no data', percent: 100 }];
    methodChart = new Chart(methodCtx, {
      type: 'doughnut',
      data: {
        labels: methods.map(m => m.method),
        datasets: [{ data: methods.map(m => m.percent), backgroundColor: ['#2F6FED', '#7C5CFC', '#FF8A3D', '#16C79A', '#E5484D', '#6B7280'] }],
      },
      options: { plugins: { legend: { position: 'bottom' } } },
    });

    const body = document.getElementById('recentTxnBody');
    body.innerHTML = d.recent_transactions.length ? d.recent_transactions.map(t => `
      <tr><td>${t.txn_ref_no}</td><td>${t.type.replace('_',' ')}</td><td>${money(t.amount)}</td>
      <td><span class="badge ${t.status}">${t.status.replace('_',' ')}</span></td><td>${timeAgo(t.created_at)}</td></tr>
    `).join('') : `<tr><td colspan="5" class="empty-state">No transactions yet</td></tr>`;
  } catch (e) { showToast(e.message, true); }
}

async function loadUsers() {
  const body = document.getElementById('usersBody');
  try {
    const users = await api('/api/admin/users');
    body.innerHTML = users.map(u => `
      <tr>
        <td>${u.name}</td><td>${u.email}</td><td>${u.mobile}</td><td>${u.role}</td>
        <td><span class="badge ${u.status}">${u.status}</span></td>
        <td>
          <select onchange="updateUserStatus('${u.id}', this.value)" style="padding:5px 8px;border-radius:6px;border:1px solid var(--border);font-size:12px;">
            <option value="">Change status…</option>
            <option value="active">Activate</option>
            <option value="suspended">Suspend</option>
          </select>
          <button class="btn btn-sm btn-primary" style="width:auto;display:inline-flex;margin-left:6px;" onclick="addBalance('${u.id}', '${u.name.replace(/'/g, "\\'")}')">Add Balance</button>
        </td>
      </tr>`).join('');
  } catch (e) { body.innerHTML = `<tr><td colspan="6" class="empty-state">Couldn't load users</td></tr>`; }
}

async function updateUserStatus(userId, status) {
  if (!status) return;
  try {
    await api(`/api/admin/users/${userId}/status`, { method: 'PATCH', body: { status } });
    showToast('User status updated');
    loadUsers();
  } catch (e) { showToast(e.message, true); }
}

async function addBalance(userId, name) {
  const raw = prompt(`Amount to credit to ${name}'s account (enter a negative number to debit):`);
  if (raw === null) return; // cancelled
  const amount = parseFloat(raw);
  if (isNaN(amount) || amount === 0) { showToast('Enter a valid non-zero amount', true); return; }
  try {
    const res = await api(`/api/admin/users/${userId}/balance`, { method: 'POST', body: { amount } });
    showToast(`${res.message} — new balance ${money(res.new_balance)}`);
  } catch (e) { showToast(e.message, true); }
}

async function loadAdmins() {
  const body = document.getElementById('adminsBody');
  try {
    const admins = await api('/api/admin/admins');
    body.innerHTML = admins.length ? admins.map(a => `
      <tr>
        <td>${a.name}</td><td>${a.email}</td><td>${a.role}</td>
        <td><span class="badge ${a.status}">${a.status}</span></td>
      </tr>`).join('') : `<tr><td colspan="4" class="empty-state">No admin/operator accounts yet</td></tr>`;
  } catch (e) { body.innerHTML = `<tr><td colspan="4" class="empty-state">Couldn't load admin accounts</td></tr>`; }
}

async function createAdminAccount() {
  const name = document.getElementById('newAdminName').value.trim();
  const email = document.getElementById('newAdminEmail').value.trim();
  const password = document.getElementById('newAdminPassword').value;
  const role = document.getElementById('newAdminRole').value;

  if (!name || !email || !password) { showToast('Fill in name, email, and password', true); return; }
  if (password.length < 8) { showToast('Password should be at least 8 characters', true); return; }

  try {
    const res = await api('/api/admin/create-admin', { method: 'POST', body: { name, email, password, role } });
    showToast(`${role} account created for ${res.email}` + (res.generated_pin ? ` — txn PIN: ${res.generated_pin}` : ''));
    document.getElementById('newAdminName').value = '';
    document.getElementById('newAdminEmail').value = '';
    document.getElementById('newAdminPassword').value = '';
    loadAdmins();
  } catch (e) { showToast(e.message, true); }
}

async function loadKyc() {
  const body = document.getElementById('kycBody');
  try {
    const records = await api('/api/admin/kyc/pending');
    body.innerHTML = records.length ? records.map(r => `
      <tr>
        <td>${r.user_id.slice(0, 8)}…</td><td>${r.kyc_type}</td><td>${r.doc_url}</td><td>${timeAgo(r.created_at)}</td>
        <td>
          <button class="btn btn-sm btn-primary" style="width:auto;display:inline-flex;" onclick="decideKyc('${r.id}', true)">Approve</button>
          <button class="btn btn-sm btn-danger" style="width:auto;display:inline-flex;" onclick="decideKyc('${r.id}', false)">Reject</button>
        </td>
      </tr>`).join('') : `<tr><td colspan="5" class="empty-state">No pending KYC requests</td></tr>`;
  } catch (e) { body.innerHTML = `<tr><td colspan="5" class="empty-state">Couldn't load KYC queue</td></tr>`; }
}

async function decideKyc(id, approve) {
  try {
    await api(`/api/admin/kyc/${id}/decision`, { method: 'PATCH', body: { approve } });
    showToast(approve ? 'KYC approved' : 'KYC rejected');
    loadKyc();
  } catch (e) { showToast(e.message, true); }
}

async function loadBalanceRequests() {
  const body = document.getElementById('balanceReqBody');
  try {
    const reqs = await api('/api/admin/balance-requests/pending');
    body.innerHTML = reqs.length ? reqs.map(r => `
      <tr>
        <td>${r.user_name}</td><td>${r.user_email}</td><td>${money(r.amount)}</td>
        <td>${r.note || '—'}</td><td>${timeAgo(r.created_at)}</td>
        <td>
          <button class="btn btn-sm btn-primary" style="width:auto;display:inline-flex;" onclick="decideBalanceRequest('${r.id}', true)">Approve</button>
          <button class="btn btn-sm btn-danger" style="width:auto;display:inline-flex;" onclick="decideBalanceRequest('${r.id}', false)">Reject</button>
        </td>
      </tr>`).join('') : `<tr><td colspan="6" class="empty-state">No pending Add Money requests</td></tr>`;
  } catch (e) { body.innerHTML = `<tr><td colspan="6" class="empty-state">Couldn't load balance requests</td></tr>`; }
}

async function decideBalanceRequest(id, approve) {
  let remarks = null;
  if (!approve) {
    remarks = prompt('Reason for rejecting this request (optional):') || null;
  }
  try {
    const res = await api(`/api/admin/balance-requests/${id}/decision`, { method: 'PATCH', body: { approve, remarks } });
    showToast(res.message);
    loadBalanceRequests();
  } catch (e) { showToast(e.message, true); }
}

async function loadTransactions() {
  const body = document.getElementById('allTxnBody');
  try {
    const txns = await api('/api/admin/transactions');
    body.innerHTML = txns.length ? txns.map(t => `
      <tr>
        <td>${t.txn_ref_no}</td><td>${t.sender_id.slice(0,8)}…</td><td>${t.receiver_id ? t.receiver_id.slice(0,8)+'…' : '—'}</td>
        <td>${money(t.amount)}</td><td>${t.type.replace('_',' ')}</td>
        <td><span class="badge ${t.status}">${t.status.replace('_',' ')}</span></td><td>${timeAgo(t.created_at)}</td>
      </tr>`).join('') : `<tr><td colspan="7" class="empty-state">No transactions yet</td></tr>`;
  } catch (e) { body.innerHTML = `<tr><td colspan="7" class="empty-state">Couldn't load transactions</td></tr>`; }
}

async function loadFraud() {
  const body = document.getElementById('fraudBody');
  try {
    const alerts = await api('/api/admin/fraud-alerts');
    body.innerHTML = alerts.length ? alerts.map(a => `
      <tr>
        <td>${a.transaction_id.slice(0,8)}…</td>
        <td>${Math.round(a.risk_score*100)}%</td>
        <td><span class="badge ${a.status}">${a.status}</span></td>
        <td>${a.reason || '—'}</td>
        <td>${timeAgo(a.created_at)}</td>
      </tr>`).join('') : `<tr><td colspan="5" class="empty-state">No fraud alerts — all clear ✅</td></tr>`;
  } catch (e) { body.innerHTML = `<tr><td colspan="5" class="empty-state">Couldn't load fraud alerts</td></tr>`; }
}

async function resolveDispute() {
  const txnId = document.getElementById('disputeTxnId').value.trim();
  if (!txnId) { showToast('Enter a transaction ID', true); return; }
  try {
    const res = await api(`/api/admin/disputes/${txnId}/resolve`, {
      method: 'POST',
      body: {
        resolution: document.getElementById('disputeResolution').value,
        remarks: document.getElementById('disputeRemarks').value || null,
      },
    });
    showToast(res.message);
  } catch (e) { showToast(e.message, true); }
}

async function loadReports() {
  try {
    const summary = await api('/api/admin/reports/summary');
    const entries = Object.entries(summary.transactions_by_status || {});
    const ctx = document.getElementById('reportChart');
    if (reportChart) reportChart.destroy();
    reportChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: entries.length ? entries.map(([k]) => k.replace('_', ' ')) : ['no data'],
        datasets: [{ label: 'Transactions', data: entries.length ? entries.map(([, v]) => v) : [0], backgroundColor: '#7C5CFC' }],
      },
      options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } },
    });
  } catch (e) { showToast(e.message, true); }
}

async function loadConfig() {
  try {
    const cfg = await api('/api/admin/config');
    document.getElementById('cfgBlock').textContent = Math.round(cfg.fraud_block_threshold * 100) + '%';
    document.getElementById('cfgReview').textContent = Math.round(cfg.fraud_review_threshold * 100) + '%';
    document.getElementById('cfgLimit').textContent = money(cfg.daily_transfer_limit);
  } catch (e) { showToast(e.message, true); }
}

loadOverview();