// Point this at your running PayFlow backend.
// Normal (non-container) dev default:
window.PAYFLOW_API_BASE = "http://localhost:8000";

// When containerized with Podman + placed behind the API Gateway route,
// update this to the gateway's exposed URL, e.g.:
// window.PAYFLOW_API_BASE = "http://localhost:8080";
